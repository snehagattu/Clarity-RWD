$(document).ready(function() {
	$("#hamburger-button").click(function(){
        $(".nav-dropdown").slideToggle();
    });
});

//Javascript is used to implement slide-toggle function in mobile version of the site